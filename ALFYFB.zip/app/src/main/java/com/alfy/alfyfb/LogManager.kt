package com.alfy.alfyfb

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.time.LocalTime
import java.time.format.DateTimeFormatter

/** In-App Logcat: ring buffer thread-safe yang bisa diamati dari UI. */
object LogManager {
    const val TAG_CANDIDATE = "CAND"
    const val TAG_COOKIE = "COOKIE"
    const val TAG_IMAGE = "IMG"

    private const val MAX_LINES = 300
    private val formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SSS")
    private val lines = ArrayDeque<String>()
    private val _logs = MutableLiveData<List<String>>(emptyList())

    val logs: LiveData<List<String>> get() = _logs

    fun log(tag: String, message: String) {
        val line = "${LocalTime.now().format(formatter)} [$tag] $message"
        Log.d("ALFYFB", line)
        synchronized(lines) {
            lines.addLast(line)
            while (lines.size > MAX_LINES) lines.removeFirst()
            _logs.postValue(lines.toList())
        }
    }

    fun clear() {
        synchronized(lines) {
            lines.clear()
            _logs.postValue(emptyList())
        }
    }
}
