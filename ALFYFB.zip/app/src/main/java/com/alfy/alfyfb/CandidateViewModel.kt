package com.alfy.alfyfb

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

data class Candidate(
    val type: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

/** Menyimpan kandidat konten (max 200, tanpa duplikat). Aman dipanggil dari thread mana pun. */
class CandidateViewModel : ViewModel() {

    private val items = ArrayList<Candidate>()
    private val keys = HashSet<String>()
    private val _candidates = MutableLiveData<List<Candidate>>(emptyList())

    val candidates: LiveData<List<Candidate>> get() = _candidates

    /** @return true jika kandidat baru ditambahkan (bukan duplikat). */
    fun add(type: String, url: String): Boolean {
        synchronized(this) {
            if (!keys.add(keyOf(type, url))) return false
            items.add(Candidate(type, url))
            if (items.size > MAX_CANDIDATES) {
                val removed = items.removeAt(0)
                keys.remove(keyOf(removed.type, removed.url))
            }
            _candidates.postValue(items.toList())
        }
        val hint = if (type == TYPE_IMAGE) "(${imageHint(url)})" else ""
        LogManager.log(LogManager.TAG_CANDIDATE, "type=$type$hint url=$url")
        return true
    }

    fun lastImageUrl(): String? = synchronized(this) {
        items.lastOrNull { it.type == TYPE_IMAGE }?.url
    }

    private fun keyOf(type: String, url: String) = "$type|$url"

    companion object {
        const val MAX_CANDIDATES = 200
        const val TYPE_IFRAME_VIDEO = "iframe_video"
        const val TYPE_VIDEO_DOM = "video_dom"
        const val TYPE_IMAGE = "image"
        const val TYPE_HLS = "hls"

        /** Deteksi jenis gambar dari pola URL (hanya untuk label log). */
        fun imageHint(url: String): String {
            val u = url.lowercase()
            return when {
                "/highlights/" in u -> "highlight"
                "/stories/" in u -> "story"
                "/photo" in u -> "photo"
                "profile" in u -> "profile"
                else -> "image"
            }
        }
    }
}
