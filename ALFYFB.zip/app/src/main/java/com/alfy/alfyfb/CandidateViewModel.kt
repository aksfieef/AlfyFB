package com.alfy.alfyfb

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

data class Candidate(
    val type: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

/** Menyimpan kandidat konten (max 200, tanpa duplikat). Aman dipanggil dari thread mana pun. */
class CandidateViewModel : ViewModel() {

    private val items = ArrayList<Candidate>()
    private val keys = HashSet<String>()
    private val _candidates = MutableLiveData<List<Candidate>>(emptyList())

    val candidates: LiveData<List<Candidate>> get() = _candidates

    /** @return true jika kandidat baru ditambahkan (bukan duplikat). */
    fun add(type: String, url: String): Boolean {
        synchronized(this) {
            if (!keys.add(keyOf(type, url))) return false
            items.add(Candidate(type, url))
            if (items.size > MAX_CANDIDATES) {
                val removed = items.removeAt(0)
                keys.remove(keyOf(removed.type, removed.url))
            }
            _candidates.postValue(items.toList())
        }
        val hint = if (type == TYPE_IMAGE) "(${imageHint(url)})" else ""
        LogManager.log(LogManager.TAG_CANDIDATE, "type=$type$hint url=$url")
        return true
    }

    /** Gambar DOM terbaru; jika belum ada, fallback ke og:image terbaru. */
    fun lastImageUrl(): String? = synchronized(this) {
        items.lastOrNull { it.type == TYPE_IMAGE }?.url
            ?: items.lastOrNull { it.type == TYPE_OG_IMAGE }?.url
    }

    /** URL video untuk diunduh, urut prioritas: iframe_video_hd > reel_fallback_mp4 > og_video > json_video > iframe_video (terbaru per jenis). */
    fun videoUrlsByPriority(): List<String> = synchronized(this) {
        VIDEO_PRIORITY.mapNotNull { t -> items.lastOrNull { it.type == t }?.url }
    }

    private fun keyOf(type: String, url: String) = "$type|$url"

    companion object {
        const val MAX_CANDIDATES = 200
        const val TYPE_IFRAME_VIDEO = "iframe_video"
        const val TYPE_VIDEO_DOM = "video_dom"
        const val TYPE_IMAGE = "image"
        const val TYPE_JSON_VIDEO = "json_video"
        const val TYPE_OG_VIDEO = "og_video"
        const val TYPE_OG_IMAGE = "og_image"

        /** Hasil ekstraksi .mp4 dari HTML iframe (native fetch). */
        const val TYPE_IFRAME_VIDEO_HD = "iframe_video_hd"
        /** Hasil rewrite URL /reel/ -> m.facebook.com/watch/?v=<id> lalu ekstraksi .mp4. */
        const val TYPE_REEL_FALLBACK = "reel_fallback_mp4"

        /** Prioritas unduhan (tertinggi dulu). */
        private val VIDEO_PRIORITY = listOf(
            TYPE_IFRAME_VIDEO_HD,
            TYPE_REEL_FALLBACK,
            TYPE_OG_VIDEO,
            TYPE_JSON_VIDEO,
            TYPE_IFRAME_VIDEO
        )

        fun isImageType(type: String) = type == TYPE_IMAGE || type == TYPE_OG_IMAGE

        /** Tipe yang boleh memunculkan FAB unduh (semua tipe video di VIDEO_PRIORITY). */
        fun isVideoType(type: String) = type in VIDEO_PRIORITY

        /** Deteksi jenis gambar dari pola URL (hanya untuk label log). */
        fun imageHint(url: String): String {
            val u = url.lowercase()
            return when {
                "/highlights/" in u -> "highlight"
                "/stories/" in u -> "story"
                "/photo" in u -> "photo"
                "profile" in u -> "profile"
                else -> "image"
            }
        }
    }
}
