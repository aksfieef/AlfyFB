package com.alfy.alfyfb

import android.content.Context
import android.webkit.CookieManager

/** Menyimpan/memulihkan cookie Facebook di SharedPreferences (key "fb_cookies"). */
object CookieHelper {
    private const val PREFS = "alfyfb_prefs"
    const val KEY_COOKIES = "fb_cookies"

    private val URLS = listOf(
        "https://m.facebook.com",
        "https://www.facebook.com",
        "https://facebook.com"
    )
    private val HTTP_ONLY = setOf("xs", "fr", "datr", "sb")

    /** Ambil semua cookie facebook dari CookieManager sebagai peta nama -> nilai. */
    private fun collect(): LinkedHashMap<String, String> {
        val cm = CookieManager.getInstance()
        val map = LinkedHashMap<String, String>()
        for (url in URLS) {
            val raw = cm.getCookie(url) ?: continue
            for (pair in raw.split(";")) {
                val p = pair.trim()
                val idx = p.indexOf('=')
                if (idx > 0) map[p.substring(0, idx)] = p.substring(idx + 1)
            }
        }
        return map
    }

    private fun serialize(map: Map<String, String>): String =
        map.entries.joinToString("; ") { "${it.key}=${it.value}" }

    fun stored(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_COOKIES, null)?.takeIf { it.isNotBlank() }

    /** Dipanggil setiap halaman selesai; menyimpan hanya jika login terdeteksi (c_user + xs). */
    fun captureIfLoggedIn(context: Context) {
        val map = collect()
        if (!map.containsKey("c_user") || !map.containsKey("xs")) return
        val joined = serialize(map)
        if (joined == stored(context)) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_COOKIES, joined).apply()
        LogManager.log(LogManager.TAG_COOKIE, "Cookie disimpan: ${map.size} cookie (login terdeteksi)")
    }

    /** Dipanggil saat app dibuka; memulihkan cookie jika sesi WebView sudah hilang. */
    fun restore(context: Context) {
        val saved = stored(context)
        if (saved == null) {
            LogManager.log(LogManager.TAG_COOKIE, "Restore: belum ada cookie tersimpan")
            return
        }
        if (collect().containsKey("c_user")) {
            LogManager.log(LogManager.TAG_COOKIE, "Restore dilewati: sesi WebView masih aktif")
            return
        }
        val cm = CookieManager.getInstance()
        var count = 0
        for (pair in saved.split(";")) {
            val p = pair.trim()
            val idx = p.indexOf('=')
            if (idx <= 0) continue
            val name = p.substring(0, idx)
            val attrs = StringBuilder("$p; Domain=.facebook.com; Path=/; Secure; Max-Age=31536000")
            if (name in HTTP_ONLY) attrs.append("; HttpOnly")
            cm.setCookie("https://m.facebook.com", attrs.toString())
            count++
        }
        cm.flush()
        LogManager.log(LogManager.TAG_COOKIE, "Cookie dipulihkan: $count cookie")
    }
}
