package com.alfy.alfyfb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.text.format.Formatter
import android.webkit.CookieManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.ResponseBody
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Foreground service antrean unduhan video (satu per satu).
 * OkHttp (dengan cookie) -> MediaStore Movies/ALFYFB, status ditulis ke Room, progres di notifikasi.
 */
class DownloadService : Service() {

    private class Task(val id: Long, val urls: List<String>, val title: String, val generation: Int)

    private class DownloadCancelled : IOException("Dibatalkan")

    private val mainHandler = Handler(Looper.getMainLooper())
    private val dbExecutor = Executors.newSingleThreadExecutor()
    private val downloadExecutor = Executors.newSingleThreadExecutor()
    private val active = AtomicInteger(0)
    private val activeKeys: MutableSet<String> = Collections.synchronizedSet(HashSet())

    /** Naik setiap kali pengguna menekan "Batal"; task dengan generasi lama dianggap dibatalkan. */
    @Volatile private var generation = 0
    @Volatile private var currentCall: Call? = null

    @Volatile private var curTitle = ""
    @Volatile private var curText = ""
    @Volatile private var curPct = -1
    private var lastNotifyAt = 0L

    private lateinit var nm: NotificationManager
    private lateinit var dao: DownloadDao

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.dl_channel_name), NotificationManager.IMPORTANCE_LOW)
        )
        dao = AppDatabase.get(this).downloadDao()
        curTitle = getString(R.string.dl_default_title)
        curText = getString(R.string.dl_preparing)
        dbExecutor.execute { dao.failStale() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancelAll()
            return START_NOT_STICKY
        }

        active.incrementAndGet()
        // Wajib dipanggil setiap kali dimulai lewat startForegroundService().
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildProgressNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        val urls = intent?.getStringArrayListExtra(EXTRA_URLS)?.filter { it.isNotBlank() }.orEmpty()
        val title = intent?.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() }
            ?: getString(R.string.dl_default_title)
        if (urls.isEmpty() || !activeKeys.add(urls[0])) { // kosong / sudah ada di antrean
            finishOne()
            return START_NOT_STICKY
        }

        val gen = generation
        dbExecutor.execute {
            val id = dao.insert(DownloadEntity(url = urls[0], title = title, status = DownloadStatus.QUEUED))
            downloadExecutor.execute { runTask(Task(id, urls, title, gen)) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        currentCall?.cancel()
        downloadExecutor.shutdownNow()
        dbExecutor.shutdown()
        super.onDestroy()
    }

    private fun cancelAll() {
        generation++
        currentCall?.cancel()
        LogManager.log(TAG, "Semua unduhan dibatalkan pengguna")
        if (active.get() <= 0) stopIfIdle()
    }

    // ---------------------------------------------------------------- task

    private fun runTask(task: Task) {
        try {
            if (task.generation != generation) throw DownloadCancelled()
            dao.updateStatus(task.id, DownloadStatus.DOWNLOADING)
            curTitle = task.title
            curText = getString(R.string.dl_preparing)
            curPct = -1
            pushProgress(force = true)

            val uri = downloadFirstWorking(task)
            dao.finish(task.id, DownloadStatus.DONE, uri)
            LogManager.log(TAG, "Sukses: Movies/ALFYFB -> $uri")
            postResult(task, getString(R.string.dl_done), uri)
        } catch (e: Exception) {
            if (e is DownloadCancelled || task.generation != generation) {
                dao.finish(task.id, DownloadStatus.CANCELED, null)
                LogManager.log(TAG, "Dibatalkan: ${task.urls[0]}")
            } else {
                dao.finish(task.id, DownloadStatus.FAILED, null)
                val reason = e.message ?: e.javaClass.simpleName
                LogManager.log(TAG, "Gagal: $reason")
                postResult(task, getString(R.string.dl_failed, reason), null)
            }
        } finally {
            currentCall = null
            activeKeys.remove(task.urls[0])
            finishOne()
        }
    }

    /** Coba URL berurutan (prioritas); pakai yang pertama berhasil. */
    private fun downloadFirstWorking(task: Task): String {
        var last: Exception? = null
        for (url in task.urls) {
            try {
                return download(task, url, depth = 0)
            } catch (e: Exception) {
                if (e is DownloadCancelled || task.generation != generation) throw DownloadCancelled()
                LogManager.log(TAG, "URL gagal (${e.message}): $url")
                last = e
            }
        }
        throw last ?: IOException("Tidak ada URL video")
    }

    private fun download(task: Task, url: String, depth: Int): String {
        LogManager.log(TAG, "Unduh: $url")
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", MainActivity.USER_AGENT)
            .header("Referer", "https://m.facebook.com/")
            .header("Accept", "video/mp4,video/*;q=0.9,*/*;q=0.8")
        cookieFor(url)?.let { builder.header("Cookie", it) }

        val call = client.newCall(builder.build())
        currentCall = call
        call.execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val body = resp.body ?: throw IOException("Respons kosong")
            val mime = body.contentType()?.let { "${it.type}/${it.subtype}".lowercase(Locale.US) } ?: ""

            val isVideo = mime.startsWith("video/") || mime == "application/octet-stream" ||
                mime == "binary/octet-stream" || (mime.isEmpty() && ".mp4" in url)
            if (isVideo) return store(task, body)

            // Halaman iframe/plugin (HTML/JSON): cari URL .mp4 di dalamnya (1 tingkat).
            if (depth == 0 && (mime.startsWith("text/") || "json" in mime)) {
                val found = extractMp4Urls(resp.peekBody(MAX_PAGE_BYTES).string())
                LogManager.log(TAG, "Halaman perantara: ${found.size} URL mp4 ditemukan")
                var last: Exception? = null
                for (u in found) {
                    try {
                        return download(task, u, depth + 1)
                    } catch (e: Exception) {
                        if (e is DownloadCancelled || task.generation != generation) throw e
                        last = e
                    }
                }
                throw last ?: IOException("Tidak ada file video di halaman")
            }
            throw IOException("Bukan video (Content-Type: ${mime.ifEmpty { "-" }})")
        }
    }

    private fun store(task: Task, body: ResponseBody): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw IOException("butuh Android 10+")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val name = "ALFYFB_$stamp.mp4"
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ALFYFB")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val item = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Gagal membuat entri MediaStore")
        try {
            val total = body.contentLength()
            var read = 0L
            val buf = ByteArray(64 * 1024)
            val out = resolver.openOutputStream(item) ?: throw IOException("Gagal membuka output")
            out.use { o ->
                body.byteStream().use { input ->
                    while (true) {
                        if (task.generation != generation) throw DownloadCancelled()
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        read += n
                        curPct = if (total > 0) (read * 100 / total).toInt().coerceIn(0, 100) else -1
                        val sizeText = Formatter.formatShortFileSize(this, read)
                        curText = if (total > 0) {
                            "$curPct% · $sizeText / ${Formatter.formatShortFileSize(this, total)}"
                        } else {
                            sizeText
                        }
                        pushProgress(force = false)
                    }
                }
            }
            if (read == 0L) throw IOException("File kosong")
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(item, done, null, null)
        } catch (e: Exception) {
            resolver.delete(item, null, null)
            throw e
        }
        return item.toString()
    }

    /** Cookie live dari WebView; jika kosong dan host milik Facebook, pakai cookie tersimpan (CookieHelper). */
    private fun cookieFor(url: String): String? {
        val live = CookieManager.getInstance().getCookie(url)
        if (!live.isNullOrBlank()) return live
        val host = url.toHttpUrlOrNull()?.host ?: return null
        val isFb = FB_HOSTS.any { host == it || host.endsWith(".$it") }
        return if (isFb) CookieHelper.stored(applicationContext) else null
    }

    private fun extractMp4Urls(page: String): List<String> {
        val found = ArrayList<Pair<String, String>>()
        for (m in MP4_KEY_REGEX.findAll(page)) {
            var u = m.groupValues[2].trimEnd('\\')
            u = UNICODE_ESC_REGEX.replace(u) { it.groupValues[1].toInt(16).toChar().toString() }
            u = SLASH_ESC_REGEX.replace(u, "/").replace("&amp;", "&")
            if (".mp4" in u && found.none { it.second == u }) found.add(m.groupValues[1] to u)
        }
        return found.sortedBy { if ("hd" in it.first) 0 else 1 }.map { it.second }.take(4)
    }

    // ---------------------------------------------------------- lifecycle

    private fun finishOne() {
        if (active.decrementAndGet() <= 0) stopIfIdle()
    }

    private fun stopIfIdle() {
        mainHandler.post {
            if (active.get() <= 0) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    // ------------------------------------------------------- notifications

    private fun pushProgress(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastNotifyAt < 700) return
        lastNotifyAt = now
        nm.notify(NOTIF_ID, buildProgressNotification())
    }

    private fun buildProgressNotification(): Notification {
        val waiting = active.get() - 1
        val text = curText + if (waiting > 0) " " + getString(R.string.dl_queue_suffix, waiting) else ""
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(curTitle)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(historyIntent())
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.dl_cancel),
                PendingIntent.getService(
                    this, 1,
                    Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        if (curPct in 0..100) b.setProgress(100, curPct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun postResult(task: Task, text: String, uri: String?) {
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(task.title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(historyIntent())
            .build()
        nm.notify(RESULT_NOTIF_BASE + (task.id % 100000).toInt(), n)
    }

    private fun historyIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, HistoryActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    companion object {
        private const val TAG = "DL"
        private const val CHANNEL_ID = "alfyfb_download"
        private const val NOTIF_ID = 1001
        private const val RESULT_NOTIF_BASE = 2000
        private const val MAX_PAGE_BYTES = 4L * 1024 * 1024

        const val ACTION_CANCEL = "com.alfy.alfyfb.action.CANCEL_DOWNLOAD"
        const val EXTRA_URLS = "urls"
        const val EXTRA_TITLE = "title"

        /** True selama service hidup (dipakai HistoryActivity untuk membersihkan status basi). */
        @Volatile var running = false
            private set

        private val FB_HOSTS = listOf("facebook.com", "fbcdn.net", "fbsbx.com")
        private val MP4_KEY_REGEX = Regex(
            """((?:hd_src_no_ratelimit|hd_src|sd_src_no_ratelimit|sd_src|playable_url_quality_hd|playable_url|browser_native_hd_url|browser_native_sd_url))\\*"\s*:\s*\\*"(https?:[^"]*)"""
        )
        private val UNICODE_ESC_REGEX = Regex("""\\+u([0-9a-fA-F]{4})""")
        private val SLASH_ESC_REGEX = Regex("""\\+/""")

        private val client: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        /** Masukkan unduhan ke antrean. [urls] sudah berurutan prioritas. */
        fun enqueue(context: Context, urls: List<String>, title: String?) {
            val i = Intent(context, DownloadService::class.java)
                .putStringArrayListExtra(EXTRA_URLS, ArrayList(urls))
                .putExtra(EXTRA_TITLE, title)
            ContextCompat.startForegroundService(context, i)
        }
    }
}
