package com.alfy.alfyfb

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.CookieManager
import android.widget.Toast
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.ResponseBody
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Mengunduh gambar via OkHttp (dengan cookie) dan menyimpannya ke MediaStore Pictures/ALFYFB. */
class ImageSaver(context: Context) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    fun save(rawUrl: String) {
        LogManager.log(LogManager.TAG_IMAGE, "Simpan gambar: $rawUrl")
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            fail("butuh Android 10+ (tanpa izin penyimpanan)")
            return
        }
        executor.execute {
            try {
                val name = downloadAndSave(rawUrl)
                LogManager.log(LogManager.TAG_IMAGE, "Sukses: Pictures/ALFYFB/$name")
                toast(appContext.getString(R.string.toast_save_ok, name))
            } catch (e: Exception) {
                fail(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private fun fail(reason: String) {
        LogManager.log(LogManager.TAG_IMAGE, "Gagal: $reason")
        toast(appContext.getString(R.string.toast_save_fail, reason))
    }

    private fun toast(message: String) {
        mainHandler.post { Toast.makeText(appContext, message, Toast.LENGTH_SHORT).show() }
    }

    /** Coba URL resolusi tinggi dulu; jika gagal (mis. signature URL), pakai URL asli. */
    private fun downloadAndSave(url: String): String {
        val hd = toHdUrl(url)
        if (hd != url) {
            try {
                return fetchAndStore(hd)
            } catch (e: Exception) {
                LogManager.log(LogManager.TAG_IMAGE, "URL HD gagal (${e.message}), coba URL asli")
            }
        }
        return fetchAndStore(url)
    }

    private fun fetchAndStore(url: String): String {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", MainActivity.USER_AGENT)
            .header("Referer", "https://m.facebook.com/")
            .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
        cookieFor(url)?.let { builder.header("Cookie", it) }

        client.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val body = resp.body ?: throw IOException("Respons kosong")
            val mime = body.contentType()?.let { "${it.type}/${it.subtype}".lowercase(Locale.US) } ?: ""
            if (!mime.startsWith("image/")) {
                throw IOException("Bukan gambar (Content-Type: ${mime.ifEmpty { "-" }})")
            }
            return store(body, mime)
        }
    }

    private fun store(body: ResponseBody, mime: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw IOException("butuh Android 10+")
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val name = "ALFYFB_$stamp.${extFor(mime)}"
        val resolver = appContext.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/ALFYFB")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val item = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Gagal membuat entri MediaStore")
        try {
            val out = resolver.openOutputStream(item) ?: throw IOException("Gagal membuka output")
            out.use { o -> body.byteStream().use { it.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(item, done, null, null)
        } catch (e: Exception) {
            resolver.delete(item, null, null)
            throw e
        }
        return name
    }

    /** Cookie live dari WebView; jika kosong dan host milik Facebook, pakai cookie tersimpan. */
    private fun cookieFor(url: String): String? {
        val live = CookieManager.getInstance().getCookie(url)
        if (!live.isNullOrBlank()) return live
        val host = url.toHttpUrlOrNull()?.host ?: return null
        val isFb = FB_HOSTS.any { host == it || host.endsWith(".$it") }
        return if (isFb) CookieHelper.stored(appContext) else null
    }

    private fun extFor(mime: String): String = when (mime) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        else -> mime.substringAfter('/').substringBefore('+').ifEmpty { "img" }
    }

    companion object {
        private val FB_HOSTS = listOf("facebook.com", "fbcdn.net", "fbsbx.com")
        private val SIZE_REGEX = Regex("(stp=[^&]*_s)(\\d+)x(\\d+)")

        private val executor = Executors.newSingleThreadExecutor()
        private val client: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        /** stp=dst-jpg_s720x720 (atau ukuran s lain < 1080) -> _s1080x1080. */
        fun toHdUrl(url: String): String = SIZE_REGEX.replace(url) { m ->
            val w = m.groupValues[2].toIntOrNull()
            if (w == null || w >= 1080) m.value else "${m.groupValues[1]}1080x1080"
        }
    }
}
