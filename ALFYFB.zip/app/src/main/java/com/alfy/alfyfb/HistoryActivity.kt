package com.alfy.alfyfb

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.alfy.alfyfb.databinding.ActivityHistoryBinding
import com.alfy.alfyfb.databinding.ItemDownloadBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Riwayat unduhan video. Tap item -> buka file dengan ACTION_VIEW. */
class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val adapter = HistoryAdapter { open(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter

        val dao = AppDatabase.get(this).downloadDao()
        // Jika service tidak berjalan, status "berjalan" yang tersisa adalah sisa proses yang mati.
        if (!DownloadService.running) Thread { dao.failStale() }.start()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                dao.observeAll().collect { list ->
                    adapter.submitList(list)
                    binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun open(item: DownloadEntity) {
        val path = item.filePath
        if (item.status != DownloadStatus.DONE || path.isNullOrEmpty()) {
            Toast.makeText(this, R.string.history_not_ready, Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.parse(path)
        try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.close()
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.history_open_fail, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { // file sudah dihapus / URI tidak valid
            Toast.makeText(this, R.string.history_open_fail, Toast.LENGTH_SHORT).show()
        }
    }

    private class HistoryAdapter(
        private val onClick: (DownloadEntity) -> Unit
    ) : ListAdapter<DownloadEntity, HistoryAdapter.VH>(DIFF) {

        class VH(val b: ItemDownloadBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(ItemDownloadBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = getItem(position)
            val ctx = holder.itemView.context
            val statusRes = when (item.status) {
                DownloadStatus.QUEUED -> R.string.history_status_queued
                DownloadStatus.DOWNLOADING -> R.string.history_status_downloading
                DownloadStatus.DONE -> R.string.history_status_done
                DownloadStatus.CANCELED -> R.string.history_status_canceled
                else -> R.string.history_status_failed
            }
            val date = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(item.timestamp))
            holder.b.title.text = item.title
            holder.b.meta.text = "${ctx.getString(statusRes)} · $date"
            holder.itemView.setOnClickListener { onClick(item) }
        }

        companion object {
            private val DIFF = object : DiffUtil.ItemCallback<DownloadEntity>() {
                override fun areItemsTheSame(a: DownloadEntity, b: DownloadEntity) = a.id == b.id
                override fun areContentsTheSame(a: DownloadEntity, b: DownloadEntity) = a == b
            }
        }
    }
}
