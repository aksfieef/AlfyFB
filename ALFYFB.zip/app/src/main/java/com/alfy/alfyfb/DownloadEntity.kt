package com.alfy.alfyfb

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Satu baris riwayat unduhan. [filePath] berisi content:// URI MediaStore (Movies/ALFYFB) setelah selesai. */
@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val filePath: String? = null,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

object DownloadStatus {
    const val QUEUED = "QUEUED"
    const val DOWNLOADING = "DOWNLOADING"
    const val DONE = "DONE"
    const val FAILED = "FAILED"
    const val CANCELED = "CANCELED"
}
