package com.alfy.alfyfb

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.alfy.alfyfb.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var imageSaver: ImageSaver
    private val viewModel: CandidateViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        imageSaver = ImageSaver(applicationContext)

        setupWebView()
        CookieHelper.restore(this)
        setupSwipeRefresh()
        setupFab()
        setupLogSheet()
        setupBackHandling()

        viewModel.candidates.observe(this) { updateFab(it) }

        val restored = savedInstanceState != null && binding.webView.restoreState(savedInstanceState) != null
        if (!restored) binding.webView.loadUrl(HOME_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = USER_AGENT
        }

        webView.addJavascriptInterface(WebAppInterface(viewModel), WebAppInterface.BRIDGE_NAME)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                val bar = binding.progressBar
                if (newProgress in 1..99) {
                    bar.visibility = View.VISIBLE
                    bar.setProgressCompat(newProgress, true)
                } else {
                    bar.visibility = View.GONE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                binding.swipeRefresh.isRefreshing = false
                view.evaluateJavascript(WebAppInterface.SNIFFER_JS, null)
                CookieHelper.captureIfLoggedIn(this@MainActivity)
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val url = request.url.toString()
                if (url.contains(".m3u8", ignoreCase = true)) {
                    viewModel.add(CandidateViewModel.TYPE_HLS, url)
                }
                return null
            }
        }

        // Long-press pada <img> -> dialog simpan gambar.
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val isImage = result.type == WebView.HitTestResult.IMAGE_TYPE ||
                result.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            val url = result.extra
            if (isImage && !url.isNullOrBlank()) {
                confirmSaveImage(url)
                true
            } else {
                false
            }
        }
    }

    private fun confirmSaveImage(url: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.save_image_title)
            .setPositiveButton(R.string.save) { _, _ -> imageSaver.save(url) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.apply {
            setColorSchemeColors(ContextCompat.getColor(context, R.color.alfy_primary))
            setProgressBackgroundColorSchemeColor(ContextCompat.getColor(context, R.color.alfy_surface))
            setOnRefreshListener { binding.webView.reload() }
            setOnChildScrollUpCallback { _, _ -> binding.webView.scrollY > 0 }
        }
    }

    private fun setupFab() {
        binding.fab.setOnClickListener {
            val last = viewModel.candidates.value?.lastOrNull() ?: return@setOnClickListener
            if (last.type == CandidateViewModel.TYPE_IMAGE) {
                val url = viewModel.lastImageUrl()
                if (url != null) {
                    imageSaver.save(url)
                } else {
                    Toast.makeText(this, R.string.toast_no_image, Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, R.string.toast_video, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateFab(list: List<Candidate>) {
        val last = list.lastOrNull()
        if (last == null) {
            binding.fab.hide()
            return
        }
        if (last.type == CandidateViewModel.TYPE_IMAGE) {
            binding.fab.setImageResource(R.drawable.ic_download)
            binding.fab.contentDescription = getString(R.string.fab_save_image)
        } else {
            binding.fab.setImageResource(R.drawable.ic_play)
            binding.fab.contentDescription = getString(R.string.fab_video)
        }
        binding.fab.show()
    }

    private fun setupLogSheet() {
        binding.btnClearLog.setOnClickListener { LogManager.clear() }
        LogManager.logs.observe(this) { lines ->
            binding.logText.text = lines.joinToString("\n")
            binding.logScroll.post { binding.logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle(R.string.exit_title)
                        .setMessage(R.string.exit_message)
                        .setPositiveButton(R.string.exit_confirm) { _, _ -> finish() }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onPause() {
        binding.webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            removeJavascriptInterface(WebAppInterface.BRIDGE_NAME)
            (parent as? ViewGroup)?.removeView(this)
            destroy()
        }
        super.onDestroy()
    }

    companion object {
        const val HOME_URL = "https://m.facebook.com"
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 12; Redmi Note 5) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    }
}
