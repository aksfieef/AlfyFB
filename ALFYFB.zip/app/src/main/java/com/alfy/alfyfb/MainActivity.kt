package com.alfy.alfyfb

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.alfy.alfyfb.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var imageSaver: ImageSaver
    private val viewModel: CandidateViewModel by viewModels()

    private var pendingDownload: Pair<ArrayList<String>, String?>? = null
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { launchPendingDownload() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        imageSaver = ImageSaver(applicationContext)

        setupWebView()
        CookieHelper.restore(this)
        setupSwipeRefresh()
        setupFab()
        setupLogSheet()
        setupBackHandling()

        viewModel.candidates.observe(this) { updateFab(it) }

        val restored = savedInstanceState != null && binding.webView.restoreState(savedInstanceState) != null
        if (!restored) binding.webView.loadUrl(HOME_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            userAgentString = USER_AGENT
        }

        val bridge = WebAppInterface(viewModel, applicationContext)
        webView.addJavascriptInterface(bridge, WebAppInterface.BRIDGE_NAME)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                val bar = binding.progressBar
                if (newProgress in 1..99) {
                    bar.visibility = View.VISIBLE
                    bar.setProgressCompat(newProgress, true)
                } else {
                    bar.visibility = View.GONE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                binding.swipeRefresh.isRefreshing = false
                view.evaluateJavascript(WebAppInterface.SNIFFER_JS, null)
                bridge.fetchOpenGraphData(view.url)
                CookieHelper.captureIfLoggedIn(this@MainActivity)
            }
        }

        // Long-press pada <img> -> dialog simpan gambar.
        webView.setOnLongClickListener {
            val result = webView.hitTestResult
            val isImage = result.type == WebView.HitTestResult.IMAGE_TYPE ||
                result.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            val url = result.extra
            if (isImage && !url.isNullOrBlank()) {
                confirmSaveImage(url)
                true
            } else {
                false
            }
        }
    }

    private fun confirmSaveImage(url: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.save_image_title)
            .setPositiveButton(R.string.save) { _, _ -> imageSaver.save(url) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.apply {
            setColorSchemeColors(ContextCompat.getColor(context, R.color.alfy_primary))
            setProgressBackgroundColorSchemeColor(ContextCompat.getColor(context, R.color.alfy_surface))
            setOnRefreshListener { binding.webView.reload() }
            setOnChildScrollUpCallback { _, _ -> binding.webView.scrollY > 0 }
        }
    }

    private fun setupFab() {
        // FAB murni untuk video; gambar hanya lewat long-press (confirmSaveImage).
        binding.fab.setOnClickListener { startVideoDownload() }
        // Tahan lama FAB -> Riwayat unduhan.
        binding.fab.setOnLongClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
            true
        }
    }

    /** Tahap 2: unduh video via DownloadService (prioritas json_video > iframe_video > og_video). */
    private fun startVideoDownload() {
        val urls = viewModel.videoUrlsByPriority()
        if (urls.isEmpty()) {
            Toast.makeText(this, R.string.toast_no_video_url, Toast.LENGTH_SHORT).show()
            return
        }
        pendingDownload = ArrayList(urls) to binding.webView.title
        val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchPendingDownload()
        }
    }

    /** Unduhan tetap jalan walau izin notifikasi ditolak. */
    private fun launchPendingDownload() {
        val (urls, title) = pendingDownload ?: return
        pendingDownload = null
        DownloadService.enqueue(this, urls, title)
        Toast.makeText(this, R.string.toast_download_started, Toast.LENGTH_SHORT).show()
    }

    private fun updateFab(list: List<Candidate>) {
        // FAB hanya muncul jika ada kandidat video; kandidat gambar saja -> disembunyikan (GONE).
        if (list.none { CandidateViewModel.isVideoType(it.type) }) {
            binding.fab.hide()
            return
        }
        binding.fab.setImageResource(R.drawable.ic_play)
        binding.fab.contentDescription = getString(R.string.fab_video)
        binding.fab.show()
    }

    private fun setupLogSheet() {
        binding.btnClearLog.setOnClickListener { LogManager.clear() }
        LogManager.logs.observe(this) { lines ->
            binding.logText.text = lines.joinToString("\n")
            binding.logScroll.post { binding.logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle(R.string.exit_title)
                        .setMessage(R.string.exit_message)
                        .setPositiveButton(R.string.exit_confirm) { _, _ -> finish() }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        binding.webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onPause() {
        binding.webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            removeJavascriptInterface(WebAppInterface.BRIDGE_NAME)
            (parent as? ViewGroup)?.removeView(this)
            destroy()
        }
        super.onDestroy()
    }

    companion object {
        const val HOME_URL = "https://m.facebook.com"
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 12; Redmi Note 5) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    }
}
