package com.alfy.alfyfb

import android.content.Context
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Jembatan JS -> Kotlin. Terdaftar sebagai "AndroidBridge". Juga menjalankan fetch HTML mentah (OG, iframe, reel) via OkHttp. */
class WebAppInterface(private val viewModel: CandidateViewModel, context: Context) {

    private val appContext = context.applicationContext

    @JavascriptInterface
    fun onCandidateFound(type: String?, url: String?) {
        if (type == null || url == null) return
        if (type !in ALLOWED_TYPES) return
        if (url.isEmpty() || url.length > MAX_URL_LENGTH) return
        val added = viewModel.add(type, url)
        // Iframe baru -> ekstrak .mp4 dari HTML-nya di background (jadi kandidat iframe_video_hd).
        if (added && type == CandidateViewModel.TYPE_IFRAME_VIDEO) {
            executor.execute { fetchIframeHd(url) }
        }
    }

    /**
     * Raw HTML Fetch (pengganti OG scraper via DOM, karena SPA Facebook menghapus meta og:).
     * Dipanggil dari onPageFinished. Aman dipanggil dari main thread (kerja jaringan di background).
     * Untuk URL /reel/ sekaligus menjalankan URL rewrite ke m.facebook.com/watch/?v=<id>.
     */
    fun fetchOpenGraphData(pageUrl: String?) {
        val url = pageUrl ?: return
        if (!isFacebookUrl(url)) return
        executor.execute {
            runOgFetch(url)
            if ("/reel/" in url) runReelFallback(url)
        }
    }

    private fun runOgFetch(url: String) {
        var videos = emptyList<String>()
        var images = emptyList<String>()
        for (ua in OG_USER_AGENTS) {
            val html = fetchHtml(url, ua) ?: continue
            videos = extractOg(html, OG_VIDEO_REGEXES)
            images = extractOg(html, OG_IMAGE_REGEXES)
            if (videos.isNotEmpty() || images.isNotEmpty()) break
        }
        LogManager.log(
            TAG,
            "OG Fetch: URL=$url, og_video=${if (videos.isNotEmpty()) "found" else "not"}, " +
                "og_image=${if (images.isNotEmpty()) "found" else "not"}"
        )
        videos.forEach { viewModel.add(CandidateViewModel.TYPE_OG_VIDEO, it) }
        images.forEach { viewModel.add(CandidateViewModel.TYPE_OG_IMAGE, it) }
    }

    /** /reel/<id> -> fetch m.facebook.com/watch/?v=<id>, ekstrak .mp4 dari HTML mentah. */
    private fun runReelFallback(url: String) {
        val id = REEL_ID_REGEX.find(url)?.groupValues?.get(1)
        if (id == null) {
            LogManager.log(TAG, "Reel fallback: id tidak ditemukan di $url")
            return
        }
        val target = "https://m.facebook.com/watch/?v=$id"
        val html = fetchHtml(target, MainActivity.USER_AGENT) ?: return
        val mp4 = extractMp4Urls(html)
        LogManager.log(TAG, "Reel fallback: id=$id, mp4=${mp4.size}")
        // Terbaik (HD) ditambahkan terakhir supaya jadi "terbaru" di CandidateViewModel.
        mp4.take(2).reversed().forEach { viewModel.add(CandidateViewModel.TYPE_REEL_FALLBACK, it) }
    }

    /** Ekstrak .mp4 (browser_native_hd_url, playable_url, dst.) dari HTML iframe. */
    private fun fetchIframeHd(url: String) {
        if (!isFacebookUrl(url)) return
        val html = fetchHtml(url, MainActivity.USER_AGENT) ?: return
        val mp4 = extractMp4Urls(html)
        LogManager.log(TAG, "Iframe HD: mp4=${mp4.size}, iframe=$url")
        mp4.take(2).reversed().forEach { viewModel.add(CandidateViewModel.TYPE_IFRAME_VIDEO_HD, it) }
    }

    private fun fetchHtml(url: String, userAgent: String): String? = try {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
        cookieFor(url)?.let { builder.header("Cookie", it) }
        client.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                LogManager.log(TAG, "Fetch gagal: HTTP ${resp.code} $url")
                null
            } else {
                resp.peekBody(MAX_HTML_BYTES).string()
            }
        }
    } catch (e: Exception) {
        LogManager.log(TAG, "Fetch error (${e.message}): $url")
        null
    }

    /** Cookie live dari WebView; jika kosong, pakai cookie tersimpan CookieHelper. Hanya dipanggil untuk host Facebook. */
    private fun cookieFor(url: String): String? {
        val live = CookieManager.getInstance().getCookie(url)
        return if (!live.isNullOrBlank()) live else CookieHelper.stored(appContext)
    }

    companion object {
        const val BRIDGE_NAME = "AndroidBridge"
        private const val MAX_URL_LENGTH = 4096
        private const val TAG = "OG"
        private const val MAX_HTML_BYTES = 4L * 1024 * 1024

        /** facebookexternalhit dulu (crawler dapat meta og lengkap), lalu desktop Chrome. */
        private val OG_USER_AGENTS = listOf(
            "facebookexternalhit/1.1",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/120.0.0.0 Safari/537.36"
        )

        private val executor = Executors.newFixedThreadPool(2)
        private val client: OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        private fun ogRegexes(kind: String) = listOf(
            Regex(
                """<meta[^>]*property=["']og:$kind(?::url|:secure_url)?["'][^>]*content=["']([^"']+)["']""",
                RegexOption.IGNORE_CASE
            ),
            Regex(
                """<meta[^>]*content=["']([^"']+)["'][^>]*property=["']og:$kind(?::url|:secure_url)?["']""",
                RegexOption.IGNORE_CASE
            )
        )
        private val OG_VIDEO_REGEXES = ogRegexes("video")
        private val OG_IMAGE_REGEXES = ogRegexes("image")
        private val REEL_ID_REGEX = Regex("""/reel/(\d+)""")

        private val MP4_KEY_REGEX = Regex(
            """((?:hd_src_no_ratelimit|hd_src|sd_src_no_ratelimit|sd_src|playable_url_quality_hd|playable_url|browser_native_hd_url|browser_native_sd_url))\\*"\s*:\s*\\*"(https?:[^"]*)"""
        )
        private val UNICODE_ESC_REGEX = Regex("""\\+u([0-9a-fA-F]{4})""")
        private val SLASH_ESC_REGEX = Regex("""\\+/""")

        private fun isFacebookUrl(url: String): Boolean {
            val host = url.toHttpUrlOrNull()?.host ?: return false
            return host == "facebook.com" || host.endsWith(".facebook.com")
        }

        private fun unescapeHtml(s: String) = s
            .replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'")
            .replace("&#x2F;", "/").replace("&#38;", "&")

        private fun extractOg(html: String, regexes: List<Regex>): List<String> =
            regexes.flatMap { re -> re.findAll(html).map { unescapeHtml(it.groupValues[1]) }.toList() }
                .filter { it.startsWith("http") }
                .distinct()

        /** URL .mp4 dari HTML/JSON mentah, HD lebih dulu (maks 4). */
        fun extractMp4Urls(page: String): List<String> {
            val found = ArrayList<Pair<String, String>>()
            for (m in MP4_KEY_REGEX.findAll(page)) {
                var u = m.groupValues[2].trimEnd('\\')
                u = UNICODE_ESC_REGEX.replace(u) { it.groupValues[1].toInt(16).toChar().toString() }
                u = SLASH_ESC_REGEX.replace(u, "/").replace("&amp;", "&")
                if (".mp4" in u && found.none { it.second == u }) found.add(m.groupValues[1] to u)
            }
            return found.sortedBy { if ("hd" in it.first) 0 else 1 }.map { it.second }.take(4)
        }
        private val ALLOWED_TYPES = setOf(
            CandidateViewModel.TYPE_IFRAME_VIDEO,
            CandidateViewModel.TYPE_VIDEO_DOM,
            CandidateViewModel.TYPE_IMAGE,
            CandidateViewModel.TYPE_JSON_VIDEO,
            CandidateViewModel.TYPE_OG_VIDEO,
            CandidateViewModel.TYPE_OG_IMAGE
        )

        /** JS yang di-inject di onPageFinished. Aman dipanggil berulang. */
        const val SNIFFER_JS = """
(function () {
  try {
    if (window.__alfyfb) { window.__alfyfb.scan(); return; }
    var seen = {};
    var timer = null;

    function has(u, s) {
      if (u.indexOf(s) !== -1) return true;
      try { return decodeURIComponent(u).indexOf(s) !== -1; } catch (e) { return false; }
    }
    function abs(u) {
      try { return new URL(u, document.baseURI).href; } catch (e) { return u; }
    }
    function send(type, url) {
      if (!url || typeof url !== 'string') return;
      if (url.indexOf('data:') === 0) return;
      if (url.indexOf('blob:') === 0 && type !== 'video_dom') return;
      var key = type + '|' + url;
      if (seen[key]) return;
      seen[key] = 1;
      try { AndroidBridge.onCandidateFound(type, url); } catch (e) {}
    }
    function scan() {
      var i, j, el, u, kids;
      var frames = document.getElementsByTagName('iframe');
      for (i = 0; i < frames.length; i++) {
        u = frames[i].getAttribute('src') || frames[i].getAttribute('data-src') || '';
        if (u && (has(u, 'plugins/video.php') || has(u, 'plugins/post.php'))) {
          send('iframe_video', abs(u));
        }
      }
      var vids = document.getElementsByTagName('video');
      for (i = 0; i < vids.length; i++) {
        el = vids[i];
        u = el.getAttribute('src') || el.getAttribute('data-src') || el.currentSrc || '';
        if (u) send('video_dom', abs(u));
        kids = el.getElementsByTagName('source');
        for (j = 0; j < kids.length; j++) {
          u = kids[j].getAttribute('src') || kids[j].getAttribute('data-src') || '';
          if (u) send('video_dom', abs(u));
        }
      }
      var imgs = document.getElementsByTagName('img');
      for (i = 0; i < imgs.length; i++) {
        el = imgs[i];
        var w = el.naturalWidth || el.width || el.clientWidth || 0;
        var h = el.naturalHeight || el.height || el.clientHeight || 0;
        if (w < 200 || h < 150) continue;
        u = el.currentSrc || el.src || el.getAttribute('data-src') || '';
        if (u) send('image', abs(u));
      }
    }
    function schedule() {
      if (timer) return;
      timer = setTimeout(function () { timer = null; scan(); }, 1200);
    }
    // --- JSON manifest parser: intercept respons fetch/XHR, tetap chain ke original ---
    function extractJson(text) {
      if (!text || typeof text !== 'string') return;
      if (text.indexOf('playable_url') === -1 && text.indexOf('browser_native_hd_url') === -1 &&
          text.indexOf('browser_native_sd_url') === -1 && text.indexOf('browser_native_hd_src') === -1) return;
      var re = /(?:playable_url|browser_native_hd_url|browser_native_sd_url|browser_native_hd_src)\\*"\s*:\s*\\*"(https?:[^"]*)/g;
      var m;
      while ((m = re.exec(text)) !== null) {
        var u = m[1];
        while (u.length && u.charAt(u.length - 1) === '\\') u = u.slice(0, -1);
        u = u.replace(/\\+u([0-9a-fA-F]{4})/g, function (x, h) { return String.fromCharCode(parseInt(h, 16)); })
             .replace(/\\+\//g, '/');
        if (u.indexOf('.mp4') !== -1) send('json_video', u);
      }
    }
    try {
      var origFetch = window.fetch;
      if (typeof origFetch === 'function') {
        window.fetch = function () {
          var p = origFetch.apply(this, arguments);
          try {
            p.then(function (res) {
              try {
                if (!res || typeof res.clone !== 'function') return;
                var ct = (res.headers && res.headers.get('content-type')) || '';
                if (/video|image|audio|octet|font|wasm/i.test(ct)) return;
                res.clone().text().then(extractJson, function () {});
              } catch (e) {}
            }, function () {});
          } catch (e) {}
          return p;
        };
      }
    } catch (e) {}
    try {
      var origSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.send = function () {
        try {
          var xhr = this;
          xhr.addEventListener('load', function () {
            try {
              var rt = xhr.responseType;
              if (rt === '' || rt === 'text') extractJson(xhr.responseText);
              else if (rt === 'json') extractJson(JSON.stringify(xhr.response));
            } catch (e) {}
          });
        } catch (e) {}
        return origSend.apply(this, arguments);
      };
    } catch (e) {}
    window.__alfyfb = { scan: scan };
    try {
      new MutationObserver(schedule).observe(document.documentElement, {
        childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'data-src']
      });
      document.addEventListener('load', function (e) {
        if (e.target && e.target.tagName === 'IMG') schedule();
      }, true);
    } catch (e) {}
    scan();
  } catch (e) {}
})();
"""
    }
}
