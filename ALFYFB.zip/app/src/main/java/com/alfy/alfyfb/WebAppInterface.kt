package com.alfy.alfyfb

import android.webkit.JavascriptInterface

/** Jembatan JS -> Kotlin. Terdaftar sebagai "AndroidBridge". */
class WebAppInterface(private val viewModel: CandidateViewModel) {

    @JavascriptInterface
    fun onCandidateFound(type: String?, url: String?) {
        if (type == null || url == null) return
        if (type !in ALLOWED_TYPES) return
        if (url.isEmpty() || url.length > MAX_URL_LENGTH) return
        viewModel.add(type, url)
    }

    companion object {
        const val BRIDGE_NAME = "AndroidBridge"
        private const val MAX_URL_LENGTH = 4096
        private val ALLOWED_TYPES = setOf(
            CandidateViewModel.TYPE_IFRAME_VIDEO,
            CandidateViewModel.TYPE_VIDEO_DOM,
            CandidateViewModel.TYPE_IMAGE,
            CandidateViewModel.TYPE_JSON_VIDEO,
            CandidateViewModel.TYPE_OG_VIDEO,
            CandidateViewModel.TYPE_OG_IMAGE
        )

        /** JS yang di-inject di onPageFinished. Aman dipanggil berulang. */
        const val SNIFFER_JS = """
(function () {
  try {
    if (window.__alfyfb) { window.__alfyfb.scan(); return; }
    var seen = {};
    var timer = null;

    function has(u, s) {
      if (u.indexOf(s) !== -1) return true;
      try { return decodeURIComponent(u).indexOf(s) !== -1; } catch (e) { return false; }
    }
    function abs(u) {
      try { return new URL(u, document.baseURI).href; } catch (e) { return u; }
    }
    function send(type, url) {
      if (!url || typeof url !== 'string') return;
      if (url.indexOf('data:') === 0) return;
      if (url.indexOf('blob:') === 0 && type !== 'video_dom') return;
      var key = type + '|' + url;
      if (seen[key]) return;
      seen[key] = 1;
      try { AndroidBridge.onCandidateFound(type, url); } catch (e) {}
    }
    function scan() {
      var i, j, el, u, kids;
      var frames = document.getElementsByTagName('iframe');
      for (i = 0; i < frames.length; i++) {
        u = frames[i].getAttribute('src') || frames[i].getAttribute('data-src') || '';
        if (u && (has(u, 'plugins/video.php') || has(u, 'plugins/post.php'))) {
          send('iframe_video', abs(u));
        }
      }
      var vids = document.getElementsByTagName('video');
      for (i = 0; i < vids.length; i++) {
        el = vids[i];
        u = el.getAttribute('src') || el.getAttribute('data-src') || el.currentSrc || '';
        if (u) send('video_dom', abs(u));
        kids = el.getElementsByTagName('source');
        for (j = 0; j < kids.length; j++) {
          u = kids[j].getAttribute('src') || kids[j].getAttribute('data-src') || '';
          if (u) send('video_dom', abs(u));
        }
      }
      var imgs = document.getElementsByTagName('img');
      for (i = 0; i < imgs.length; i++) {
        el = imgs[i];
        var w = el.naturalWidth || el.width || el.clientWidth || 0;
        if (w < 200) continue;
        u = el.currentSrc || el.src || el.getAttribute('data-src') || '';
        if (u) send('image', abs(u));
      }
    }
    function schedule() {
      if (timer) return;
      timer = setTimeout(function () { timer = null; scan(); }, 1200);
    }
    // --- JSON manifest parser: intercept respons fetch/XHR, tetap chain ke original ---
    function extractJson(text) {
      if (!text || typeof text !== 'string') return;
      if (text.indexOf('playable_url') === -1 && text.indexOf('browser_native_hd_url') === -1 &&
          text.indexOf('browser_native_sd_url') === -1 && text.indexOf('browser_native_hd_src') === -1) return;
      var re = /(?:playable_url|browser_native_hd_url|browser_native_sd_url|browser_native_hd_src)\\*"\s*:\s*\\*"(https?:[^"]*)/g;
      var m;
      while ((m = re.exec(text)) !== null) {
        var u = m[1];
        while (u.length && u.charAt(u.length - 1) === '\\') u = u.slice(0, -1);
        u = u.replace(/\\+u([0-9a-fA-F]{4})/g, function (x, h) { return String.fromCharCode(parseInt(h, 16)); })
             .replace(/\\+\//g, '/');
        if (u.indexOf('.mp4') !== -1) send('json_video', u);
      }
    }
    try {
      var origFetch = window.fetch;
      if (typeof origFetch === 'function') {
        window.fetch = function () {
          var p = origFetch.apply(this, arguments);
          try {
            p.then(function (res) {
              try {
                if (!res || typeof res.clone !== 'function') return;
                var ct = (res.headers && res.headers.get('content-type')) || '';
                if (/video|image|audio|octet|font|wasm/i.test(ct)) return;
                res.clone().text().then(extractJson, function () {});
              } catch (e) {}
            }, function () {});
          } catch (e) {}
          return p;
        };
      }
    } catch (e) {}
    try {
      var origSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.send = function () {
        try {
          var xhr = this;
          xhr.addEventListener('load', function () {
            try {
              var rt = xhr.responseType;
              if (rt === '' || rt === 'text') extractJson(xhr.responseText);
              else if (rt === 'json') extractJson(JSON.stringify(xhr.response));
            } catch (e) {}
          });
        } catch (e) {}
        return origSend.apply(this, arguments);
      };
    } catch (e) {}
    window.__alfyfb = { scan: scan };
    try {
      new MutationObserver(schedule).observe(document.documentElement, {
        childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'data-src']
      });
      document.addEventListener('load', function (e) {
        if (e.target && e.target.tagName === 'IMG') schedule();
      }, true);
    } catch (e) {}
    scan();
  } catch (e) {}
})();
"""

        /** Open Graph scraper (fallback sniffer). Dipanggil terpisah setelah SNIFFER_JS; dedup dilakukan di CandidateViewModel. */
        const val OG_JS = """
(function () {
  try {
    document.querySelectorAll('meta[property^="og:"]').forEach(function (meta) {
      var prop = meta.getAttribute('property');
      var content = meta.getAttribute('content');
      if (!content) return;
      if (prop === 'og:video' || prop === 'og:video:url' || prop === 'og:video:secure_url') {
        AndroidBridge.onCandidateFound('og_video', content);
      } else if (prop === 'og:image' || prop === 'og:image:url' || prop === 'og:image:secure_url') {
        AndroidBridge.onCandidateFound('og_image', content);
      }
    });
  } catch (e) {}
})();
"""
    }
}
