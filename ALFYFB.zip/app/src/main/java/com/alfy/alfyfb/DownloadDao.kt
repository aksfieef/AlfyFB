package com.alfy.alfyfb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Insert
    fun insert(entity: DownloadEntity): Long

    @Query("UPDATE downloads SET status = :status WHERE id = :id")
    fun updateStatus(id: Long, status: String)

    @Query("UPDATE downloads SET status = :status, filePath = :filePath WHERE id = :id")
    fun finish(id: Long, status: String, filePath: String?)

    /** Unduhan yang tertinggal "berjalan" karena proses mati dianggap gagal. */
    @Query("UPDATE downloads SET status = 'FAILED' WHERE status IN ('QUEUED', 'DOWNLOADING')")
    fun failStale()

    @Query("SELECT * FROM downloads ORDER BY timestamp DESC, id DESC")
    fun observeAll(): Flow<List<DownloadEntity>>
}
