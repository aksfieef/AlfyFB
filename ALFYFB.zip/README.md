# ALFYFB (Tahap 1 — fondasi)

Browser WebView `m.facebook.com` dengan deteksi kandidat konten dan simpan gambar.
Package `com.alfy.alfyfb` · Kotlin + XML · Material 3 dark · minSdk 26 / target 34 · Gradle 8.5 · JDK 17.

**Isi:** WebView penuh + progress tipis + swipe-refresh, cookie capture/restore (`fb_cookies`),
JS bridge `AndroidBridge` + sniffer (iframe/video/img) + intercept `.m3u8`, FAB kontekstual,
simpan gambar ke `Pictures/ALFYFB` (long-press / FAB), In-App Logcat (bottom sheet, swipe up).

**Build:** `./gradlew assembleDebug` — `gradle-wrapper.jar` diunduh otomatis oleh `gradlew` bila belum ada.

**Catatan:**
- Simpan gambar memakai MediaStore tanpa izin penyimpanan, sehingga butuh Android 10+ (API 29).
- Cookie sesi (termasuk `xs`) disimpan di SharedPreferences biasa sesuai spesifikasi; `allowBackup` dimatikan.
- Video hanya dideteksi (FAB = Toast). Unduh video = Tahap 2. Tidak ada audio/FFmpeg/yt-dlp.
